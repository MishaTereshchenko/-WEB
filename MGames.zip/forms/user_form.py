from flask_wtf import FlaskForm
from flask_login import login_manager, UserMixin, LoginManager
from wtforms import PasswordField, StringField, TextAreaField, SubmitField, BooleanField, IntegerField
from wtforms.fields import EmailField
from wtforms.validators import DataRequired


class LoginForm(FlaskForm):
    email = EmailField('Почта', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    remember_me = BooleanField('Запомнить меня')
    submit = SubmitField('Войти')


class RegisterForm(FlaskForm):
    email = EmailField('Login/email', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    password_again = PasswordField('Repeat password', validators=[DataRequired()])
    surname = StringField('Surname', validators=[DataRequired()])
    name = StringField('Name', validators=[DataRequired()])
    # age = StringField('Age', validators=[DataRequired()])
    submit = SubmitField('Submit')


class MoneyAddForm(FlaskForm):
    add_money = IntegerField('Сумма пополнения', validators=[DataRequired()])
    submit = SubmitField('Пополнить')
