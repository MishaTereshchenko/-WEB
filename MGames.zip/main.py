import sqlite3

from flask import Flask
from flask import render_template, redirect
from data import db_session
from data.users import User
from data.products import Product
from data.baskets import Basket
from forms.user_form import *
from forms.product_form import ProductForm
from flask_login import LoginManager, login_user, current_user, login_required, logout_user
import product_api
import user_api

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

log_man = LoginManager()
log_man.init_app(app)


@app.route('/')
@app.route('/index', methods=["GET", "POST"])
def index():
    db_sess = db_session.create_session()
    good = db_sess.query(Product).all()

    return render_template("index.html", prod=good)


@app.route('/view_basket', methods=["GET", "POST"])
def view_basket():
    db_sess = db_session.create_session()
    korzina = db_sess.query(Basket).filter(Basket.user_id == current_user.id).first()
    tovar = db_sess.query(Product).all()

    user_id = korzina.user_id

    baza_dannyh = sqlite3.connect("db\shop.db")

    cur = baza_dannyh.cursor()
    result = cur.execute(f"""SELECT product_id FROM products_in_baskets WHERE basket_id = ?""", (user_id,)).fetchall()
    summa = 0
    skidka = 'Нет.'

    for elem in result:
        result2 = cur.execute(f"""SELECT price FROM products WHERE id = ?""", (elem[0],)).fetchall()
        summa += result2[0][0]
    res = cur.execute(f"""SELECT discount FROM promotions WHERE summa <= ?""", (summa,)).fetchall()

    if res:
        summa = int(summa * int(res[len(res) - 1][0]) / 100)
        skidka = str(100 - int(res[len(res) - 1][0])) + '%'

    return render_template("view_basket.html", prod=tovar, basket=korzina, summa=summa, skidka=skidka)


@app.route('/buy/<int:id>', methods=["GET", "POST"])
def buy(id):
    db_sess = db_session.create_session()
    tovar = db_sess.query(Product).filter(Product.id == id).first()
    korzina = db_sess.query(Basket).filter(Basket.user_id == current_user.id).first()
    korzina.products.append(tovar)
    db_sess.commit()
    return redirect("/")


@app.route('/delete_item/<int:id>', methods=["GET", "POST"])
def delete_item(id):
    db_sess = db_session.create_session()
    tovar = db_sess.query(Product).filter(Product.id == id).first()
    db_sess.delete(tovar)
    db_sess.commit()
    return redirect("/")


@app.route('/delete_item_from_basket/<int:id>', methods=["GET", "POST"])
def delete_item_from_basket(id):
    db_sess = db_session.create_session()
    tovar = db_sess.query(Product).filter(Product.id == id).first()
    korzina = db_sess.query(Basket).filter(Basket.user_id == current_user.id).first()
    korzina.products.remove(tovar)
    db_sess.commit()
    return redirect("/view_basket")


@app.route('/book/<int:id>', methods=["GET", "POST"])
def book(id):
    db_sess = db_session.create_session()

    baza_dannyh = sqlite3.connect("db\shop.db")
    cur = baza_dannyh.cursor()

    result = cur.execute(f"""SELECT product_id FROM products_in_baskets WHERE basket_id = ?""", (id,)).fetchall()

    summa = 0
    kolvo = True
    skidka = 'Нет.'

    for elem in result:
        result2 = cur.execute(f"""SELECT price FROM products WHERE id = ?""", (elem[0],)).fetchall()
        summa += result2[0][0]

        result3 = cur.execute(f"""SELECT count FROM products WHERE id = ?""", (elem[0],)).fetchall()

        if result3[0][0] == 0:
            kolvo = False

    user = db_sess.query(User).filter(User.id == current_user.id).first()

    if summa <= user.money and kolvo:
        res = cur.execute(f"""SELECT discount FROM promotions WHERE summa <= ?""", (summa,)).fetchall()

        if res:
            summa = int(summa * int(res[len(res) - 1][0]) / 100)
            skidka = str(100 - int(res[len(res) - 1][0])) + '%'

        user.money -= summa
        for elem in result:
            cur.execute("UPDATE products SET count = count - 1 WHERE id = ?", (elem[0],))
            cur.execute("DELETE FROM products_in_baskets WHERE basket_id = ?", (id,))
            baza_dannyh.commit()
        db_sess.commit()

        basket = db_sess.query(Basket).filter(Basket.user_id == current_user.id).first()
        tovar = db_sess.query(Product).all()

        return render_template("view_basket.html", prod=tovar, basket=basket, message='Поздравляем с удачной покупкой',
                               skidka=skidka)
    basket = db_sess.query(Basket).filter(Basket.user_id == current_user.id).first()
    tovar = db_sess.query(Product).all()

    return render_template("view_basket.html", prod=tovar, basket=basket, summa='0',
                           message='Товар закончился или недостаточно средств на счету', skidka=skidka)


@app.route('/main', methods=["GET", "POST"])
def main():
    db_session.global_init("db/shop.db")
    db_sess = db_session.create_session()
    db_sess.commit()
    app.register_blueprint(product_api.blueprint)
    app.register_blueprint(user_api.blueprint)
    app.run()


@log_man.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)


@app.route('/logout', methods=['GET', 'POST'])
@login_required
def logout():
    logout_user()
    return redirect("/")


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    reg_form = RegisterForm()
    if reg_form.validate_on_submit():
        if reg_form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=reg_form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == reg_form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=reg_form,
                                   message="Такой пользователь уже есть")
        client = User(
            name=reg_form.name.data,
            surname=reg_form.surname.data,
            email=reg_form.email.data,
            money=0
        )
        client.set_password(reg_form.password.data)
        db_sess.add(client)
        db_sess.commit()
        user_for_basket = db_sess.query(User).filter(User.name == client.name, User.surname == client.surname).first()
        korzina = Basket(
            user_id=user_for_basket.id,
        )
        db_sess.add(korzina)
        db_sess.commit()
        return redirect('/login')
    return render_template('register.html', title='Registration', form=reg_form)


@app.route('/login', methods=['GET', 'POST'])
def login():
    log_form = LoginForm()
    if log_form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == log_form.email.data).first()
        if log_form.email.data == log_form.password.data:
            return redirect("/")
        if user and user.check_password(log_form.password.data):
            login_user(user, remember=log_form.remember_me.data)
            prod = db_sess.query(Product).all()
            return render_template('index.html', name=user.name, prod=prod)
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=log_form)
    return render_template('login.html', title='Авторизация', form=log_form)


@app.route('/money_add', methods=['GET', 'POST'])
def money_add():
    m_add_form = MoneyAddForm()
    if m_add_form.validate_on_submit():
        if m_add_form.add_money.data <= 0:
            return render_template('money_add.html', title='Пополнение баланса', form=form,
                                   message='Должно быть положительное число')
        db_sess = db_session.create_session()
        client = db_sess.query(User).filter(User.id == current_user.id).first()
        summa = m_add_form.add_money.data + client.money
        client.money = summa
        db_sess.merge(client)
        db_sess.commit()
        return redirect('/')
    return render_template('money_add.html', title='Пополнение баланса', form=m_add_form)


@app.route('/add_product', methods=['GET', 'POST'])
def add_product():
    prod_form = ProductForm()
    if prod_form.validate_on_submit():
        db_sess = db_session.create_session()
        if db_sess.query(Product).filter(User.name == prod_form.name.data).first():
            return render_template('add_product.html', title='Добавление товара',
                                   form=prod_form,
                                   message="Такой продукт уже есть")
        tovar = Product(
            name=prod_form.name.data,
            type=prod_form.type.data,
            price=prod_form.price.data,
            count=prod_form.count.data,
            description=prod_form.description.data
        )
        db_sess.add(tovar)
        db_sess.commit()
        return redirect('/add_product')
    return render_template('add_product.html', form=prod_form)


@app.route('/dop_info/<int:id>', methods=['GET', 'POST'])
def dop_info(id):
    db_sess = db_session.create_session()
    product = db_sess.query(Product).filter(Product.id == id).first()

    baza_dannyh = sqlite3.connect("db\shop.db")
    cur = baza_dannyh.cursor()

    result = cur.execute(f"""SELECT addinfo, image, otzyv FROM Info WHERE name = ?""", (product.name,)).fetchall()

    info = result[0][0]
    img = result[0][1]
    otzyv = result[0][2]
    image = '../' + img

    return render_template('dop_info.html', image=str(image), name=product.name, info=info, otzyv=otzyv)


if __name__ == '__main__':
    main()
